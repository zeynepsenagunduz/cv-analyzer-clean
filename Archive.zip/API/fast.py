from fastapi import FastAPI, File, UploadFile,HTTPException
from pydantic import BaseModel
from fastapi.staticfiles import StaticFiles
from helper import allowed_file, handleCV, processJobText, create_point, pdf_to_text,remove_special_characters
from fastapi.middleware.cors import CORSMiddleware
import psycopg2
import json
import os 
import uuid


class Login(BaseModel):
    username: str
    password: str

class BestJobs(BaseModel):
    userid: str


class Register(BaseModel):
    username: str
    mail: str
    password: str
    role: str
    has_cv: bool
    has_jobpost: bool

class AddCourses(BaseModel):
    name: str
    keywords: str
    link: str

app = FastAPI()

app.mount("/static/cvs", StaticFiles(directory="./static/cvs"), name="static")
app.mount("/static/jobposts", StaticFiles(directory="./static/jobposts"), name="static")

# CORS ayarları
origins = [
    "*"  # Tüm originlere izin ver
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],  # Tüm HTTP metodlarına izin ver
    allow_headers=["*"],  # Tüm headerlara izin ver
    expose_headers=["*"],  # Tüm headerları expose et
    max_age=3600,  # Preflight isteklerinin cache süresi (saniye)
)

class Item(BaseModel):
    jobtext: str

ALLOWED_EXTENSIONS = set(['pdf','txt'])

@app.post("/login")
async def login(data: Login):
    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM users WHERE username='{data.username}' AND password='{data.password}'")
    conn.commit()
    returnData = cursor.fetchone()
    print(returnData)
    if(returnData == None):
        return {"message": "Login failed"}
    else:
        return {"userid": int(returnData[0]), "role": returnData[4], "has_cv": returnData[5], "has_jobpost": returnData[6] }


@app.post("/register")
async def register(data: Register):
    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM users WHERE username='{data.username}'")
    result = cursor.fetchone()
    if result:
        return {"message": "Username already exists"}
    val = f"INSERT INTO users (username, email, password, role, has_cv, has_jobpost) VALUES ('{data.username}', '{data.mail}', '{data.password}', '{data.role}', '0', '0')"
    print(f"VAL: {val}")
    cursor.execute(val)
    conn.commit()
    cursor.close()
    return {"message": "Registration successful"}



@app.post("/upload/cv")
async def create_upload_file(userid: str, file: UploadFile = File(...)):
    contents = await file.read()
    if(not allowed_file(file.filename, ALLOWED_EXTENSIONS)):
        return {"error": "File type is not allowed"}
    filename = userid
    with open(f"./static/cvs/{userid}.pdf", "wb") as f:
        f.write(contents)

    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()      
    cursor.execute(f"UPDATE users SET has_cv = True  WHERE id = {userid}")
    cv_keywords = json.dumps(handleCV(f'{userid}.pdf'))
    print('--------------')
    print(cv_keywords)
    cursor.execute(f"INSERT INTO cvs (userid, keywords) VALUES ('{userid}', '{cv_keywords}')")
    conn.commit()
    cursor.close()

    return {'message' : 'Files successfully uploaded'}

@app.post("/upload/jobpost")
async def create_upload_file(userid: str, file: UploadFile = File(...)):
    contents = await file.read()
    if(not allowed_file(file.filename, ['txt'])):
        return {"error": "File type is not allowed"}
    filename = userid
    with open(f"./static/jobposts/{userid}.txt", "wb") as f:
        f.write(contents)

    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()      
    cursor.execute(f"UPDATE users SET has_jobpost = True WHERE id = {userid}")
    conn.commit()
    cursor.close()
    return {'message' : 'Files successfully uploaded'}
   



def recommenderFunction(jobKeywords, cvKeywords):
    # this function gets best job match keywords and user cv keywords. Extracts not matching keywords and searches 
    # if there is any course that matches with not matching keywords. If there is, it returns that course.
    # jobKeywords is list 
    # cvKeywords is list
    courses = []
    notMatchingKeywords = []
    for keyword in jobKeywords :
        if keyword not in cvKeywords:
            notMatchingKeywords.append(keyword)
    
    if(len(notMatchingKeywords) == 0):
        return None
    else:
        for i in notMatchingKeywords:
            conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
            cursor = conn.cursor()
            cursor.execute(f"SELECT *  FROM courses WHERE keywords LIKE '%{i}%' ")
            result = cursor.fetchall()
            cursor.close()
            if(result != None):
                for i in result:
                    courses.append(i)


    return courses
    

@app.post("/best-job")
async def getPoint(userid: BestJobs):

    cv_keywords = processJobText(pdf_to_text(userid.userid))

    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)

    cursor = conn.cursor()

    cursor.execute("SELECT * FROM jobposts")
    jobs = cursor.fetchall()

    scores = {}
    for count,job in enumerate(jobs):
        print("jobs")
        print(jobs[3])
        scores[job[0]] = create_point(cv_keywords, json.loads(job[3]))
    # sort dict by value
    sorted_scores = {k: v for k, v in sorted(scores.items(), key=lambda item: item[1], reverse=True)}

    print(sorted_scores)

    
    # top 5 item with key and value
    best_job_keywords = []
    for job in jobs:
        if(job[0] == list(sorted_scores.keys())[0]):
            best_job_keywords = json.loads(job[3])
            break

        #  "top_five": [
        #         [
        #         13,
        #         85.71428571428571
        #         ],
        #         [
        #         181,
        #         85.71428571428571
        #         ],
        #         [
        #         53,
        #         83.33333333333334
        #         ],
        #         [
        #         65,
        #         83.33333333333334
        #         ],
        #         [
        #         68,
        #         83.33333333333334
        #         ]
        #     ]
    
    new_list = list(sorted_scores.items())[:5].copy()
    
    for count,i in enumerate(list(sorted_scores.items())[:5]):
        conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
        cursor = conn.cursor()
        cursor.execute(f"SELECT jobpost, jobpost_keywords FROM jobposts WHERE id={i[0]}")
        result = cursor.fetchone()
        new_list[count] = {"text": result[0], "keywords": remove_special_characters(result[1]).split(' '), "point": int(i[1])}

    courses = recommenderFunction(best_job_keywords, cv_keywords)
    return {"top_five": new_list, "cv_keywords": cv_keywords, "best_job_keywords": best_job_keywords,"courses": courses}


@app.post("/best-applicant")
async def getPoint(userid: str):

    with open(f"./static/jobposts/{userid}.txt", "r") as f:
        jobtext = f.read()
   
    job_keywords = processJobText(jobtext)

    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)

    cursor = conn.cursor()

    cursor.execute("SELECT * FROM cvs")
    cvs = cursor.fetchall()

    scores = {}
    for cv in cvs:
        scores[cv[1]] = create_point(json.loads(cv[2]), job_keywords)
    sorted_scores = {k: v for k, v in sorted(scores.items(), key=lambda item: item[1], reverse=True)}

    best_cv_keywords = []
    for cv in cvs:
        if(cv[1] == list(sorted_scores.keys())[0]):
            best_cv_keywords = json.loads(cv[2])
            break
    
    new_list = list(sorted_scores.items())[:5].copy()

    for count,i in enumerate(list(sorted_scores.items())[:5]):
        new_list[count] = {"userid": i[0], "point": int(i[1])}



    return {"top_five": new_list , "job_keywords": job_keywords, "best_cv_keywords":  best_cv_keywords  }




@app.get("/get-credit")
async def getPoint(userid: str):
    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)

    cursor = conn.cursor()

    cursor.execute(f"SELECT credit FROM users WHERE id={userid}")
    credit = cursor.fetchone()[0]
    return {
        "credit": credit
    }

@app.post("/set-credit")
async def getPoint(userid: str, amount: int):

    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)

    cursor = conn.cursor()

    cursor.execute(f"SELECT credit FROM users WHERE id={userid}")
    credit = cursor.fetchone()[0]

    newCredit = credit + amount

    try:
        cursor.execute(f"UPDATE users SET credit = {newCredit} WHERE id={userid}")
        return {
            "credit": newCredit
        }
    except:
        return {"message": "Error"}

@app.get("/decrease-credit")
async def getPoint(userid: str):

    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)

    cursor = conn.cursor()

    cursor.execute(f"SELECT credit FROM users WHERE id={userid}")
    credit = cursor.fetchone()[0]


    print("credit: ", credit)

    newCredit = credit - 1

    if(newCredit < 0):
        raise HTTPException(status_code=400, detail="Not enough credit")
    else:
        try:
            cursor.execute(f"UPDATE users SET credit = {newCredit} WHERE id = {userid}")
            print(f"UPDATE users SET credit = {newCredit} WHERE id={userid}")
            conn.commit()
            conn.close()
            return {
                "credit": newCredit
            }
        except Exception as e:
            print("exception", e)
            raise HTTPException(status_code=500, detail="Database error")

    

@app.get("/delete-cv/{userid}")
async def delete_cv(userid: str):
    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()      
    cursor.execute(f"UPDATE users SET has_cv = False WHERE id = {userid}")
    conn.commit()
    cursor.close()

    try:
        os.remove(f"./static/cvs/{userid}.pdf")
    except:
        pass

    return {"message": "CV deleted successfully"}

@app.get("/delete-jobpost/{userid}")
async def delete_cv(userid: str):
    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()      
    cursor.execute(f"UPDATE users SET has_jobpost = False WHERE id = {userid}")
    conn.commit()
    cursor.close()

    try:
        os.remove(f"./static/jobposts/{userid}.txt")
    except:
        pass

    return {"message": "CV deleted successfully"}


@app.get("/admin/create-invite-code")
async def generateInviteCode():
    myuuid = uuid.uuid4()

    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()
    cursor.execute(f"INSERT INTO invitecodes (code) VALUES ('{str(myuuid)}') ")
    conn.commit()
    cursor.close()
    return {"invite_code": "http://localhost:5173/register/" + str(myuuid)}

@app.get("/check-invite-code/{invite_code}")
async def checkInvideCodeIsValid(invite_code: str):
    print(invite_code)

    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM invitecodes WHERE code = '{invite_code}'")
    result = cursor.fetchone()
    cursor.close()

    if(result == None):
        raise HTTPException(status_code=400, detail="Invite code is not valid")
    else:
        if(result[2] == True):
            raise HTTPException(status_code=400, detail="Invite code is not valid")
        raise HTTPException(status_code=200, detail="Invite code is valid")


@app.post("/admin/add-courses")
async def add_courses(addCourses: AddCourses):
    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()      
    cursor.execute(f"INSERT INTO courses (name, keywords, link) VALUES ('{addCourses.name}', '{addCourses.keywords}', '{addCourses.link}')")
    conn.commit()
    cursor.close()
    return {"message": "CV deleted successfully"}


@app.get("/admin/get-courses")
async def get_courses():
    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM courses")
    result = cursor.fetchall()
    cursor.close()
    return {"courses": result}


@app.get("/admin/get-course/{courseid}")
async def get_courses(courseid: str):
    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM courses WHERE id={courseid}")
    result = cursor.fetchone()
    cursor.close()
    return {"courses": result}


@app.post("/admin/edit-courses")
async def edit_courses(addCourses: AddCourses):
    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()
    cursor.execute(f"UPDATE courses SET name = '{addCourses.name}', keywords = '{addCourses.keywords}', link = '{addCourses.link}' WHERE id = {addCourses.id}")
    cursor.commit()
    cursor.close()

    return {"courses": addCourses}



@app.get("/admin/delete-course/{courseid}")
async def edit_courses(courseid):
    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()
    cursor.execute(f"DELETE FROM courses WHERE id = {courseid}")
    conn.commit()
    cursor.close()
    return {"courses": True}



@app.get("/admin/stats")
async def get_stats():
    stats = {}
    conn = psycopg2.connect(host="94.102.3.157",database="TEZ_DB",user="postgres",password="GbGcdwjDgkMgdNIRWyMuku04tWkX7GZ7JT5D6PspMw2kacEnsmZMz0UjcveRvBwY",port=5455)
    cursor = conn.cursor()
    cursor.execute(f"SELECT COUNT(*) FROM users WHERE has_cv = True")
    result = cursor.fetchone()
    stats['applicantCount'] = int(result[0])
    cursor.execute(f"SELECT COUNT(*) FROM users WHERE has_jobpost = True")
    result = cursor.fetchone()
    stats['headHunterCount'] = int(result[0])
    cursor.execute(f"SELECT COUNT(*) FROM cvs")
    result = cursor.fetchone()
    stats['cvCount'] = int(result[0])
    cursor.execute(f"SELECT COUNT(*) FROM jobposts")
    result = cursor.fetchone()
    stats['jobPostCount'] = int(result[0])
    cursor.close()

    return {"stats": stats}







