from helper import create_point
x = ['html', 'css', 'mongodb', 'github', 'attention to detail']
y = ["html", "css", "javascript", "react", "angular", "jquery", "flexibility"]


print(create_point(x,y))